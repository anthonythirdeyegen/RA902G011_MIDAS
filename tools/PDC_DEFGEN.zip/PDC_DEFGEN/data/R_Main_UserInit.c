#include "R_Main_UserInit.h"

USHORT gusRcvMess[@{ROM[0xF8C2,2]:D}U];
USHORT gusSndMess[@{ROM[0xF8C0,2]:D}U];

/***********************************************************************************************************************
* Function Name: R_MAIN_UserInit
* Description  : This function adds user code before implementing main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_UserInit(void)
{
    /* Start user code. Do not edit comment generated here */
	
	// set post and source power and sink power before pd_core_init()
	pdc_set_port_conf(@{
						(ROM[0xF818,1]&0x7F) == 0b0010100 ? "PDC_ROLE_SNK_UFP" :
						(ROM[0xF818,1]&0x7F) == 0b0110100 ? "PDC_ROLE_SNK_DRD" :
						(ROM[0xF818,1]&0x7F) == 0b0101000 ? "PDC_ROLE_SRC_DFP" :
						(ROM[0xF818,1]&0x7F) == 0b0111000 ? "PDC_ROLE_SRC_DRD" :
						(ROM[0xF818,1]&0x7F) == 0b0111100 ? "PDC_ROLE_DRP_DRD" :
						(ROM[0xF818,1]&0x7F) == 0b0111111 ? "PDC_ROLE_DRP_DRD_TSNK" :
						(ROM[0xF818,1]&0x7F) == 0b0111110 ? "PDC_ROLE_DRP_DRD_TSRC" :
						(ROM[0xF818,1]&0x7F) == 0b1110100 ? "PDC_ROLE_DRP_DRD_DEFSNK" :
						(ROM[0xF818,1]&0x7F) == 0b1111000 ? "PDC_ROLE_DRP_DRD_DEFSRC" : ""
						}, @{
						((ROM[0xF819,1]&0xF) & ((ROM[0xF819,1]&0xF) - 1)) != 0 ? "(" : "" 
						}@{ (ROM[0xF819,1]&0b1000) != 0 ? "PDC_ACS_AUDIO" : ""
						}@{ (ROM[0xF819,1]&0b1000) != 0 && (ROM[0xF819,1]&0b0100) != 0 ? " | " : ""
						}@{ (ROM[0xF819,1]&0b0100) != 0 ? "PDC_ACS_DEBUG" : ""
						}@{ (ROM[0xF819,1]&0b1100) != 0 && (ROM[0xF819,1]&0b0010) != 0 ? " | " : ""
						}@{ (ROM[0xF819,1]&0b0010) != 0 ? "PDC_ACS_PWR" : ""
						}@{ (ROM[0xF819,1]&0b1110) != 0 && (ROM[0xF819,1]&0b0001) != 0 ? " | " : ""
						}@{ (ROM[0xF819,1]&0b0001) != 0 ? "PDC_ACS_VCONN" : ""
						}@{ ((ROM[0xF819,1]&0xF) & ((ROM[0xF819,1]&0xF) - 1)) != 0 ? ")" : ""
						}@{ (ROM[0xF819,1]&0b1111) == 0 ? "0" : ""
						});
	pdc_set_src_conf(@{
					(ROM[0xF818,1]==0b0010100 || ROM[0xF818,1]==0b0110100) ? 
					0 : ROM[0xF900,4]}U, @{
					(ROM[0xF818,1]==0b0010100 || ROM[0xF818,1]==0b0110100) ? 
					1 : ROM[0xF904,1]}, @{
					(ROM[0xF818,1]==0b0010100 || ROM[0xF818,1]==0b0110100) ? 
					0 : ROM[0xF905,1]&0x1}, @{
					(ROM[0xF818,1]==0b0010100 || ROM[0xF818,1]==0b0110100) ? "PDC_NOPD_CUR_0_5A" :
					(ROM[0xF906,1]&0x03) == 0b00 ? "PDC_NOPD_CUR_0_5A" :
					(ROM[0xF906,1]&0x03) == 0b01 ? "PDC_NOPD_CUR_0_9A" :
					(ROM[0xF906,1]&0x03) == 0b10 ? "PDC_NOPD_CUR_1_5A" :
					(ROM[0xF906,1]&0x03) == 0b11 ? "PDC_NOPD_CUR_3_0A" : ""
					});
	pdc_set_snk_conf(@{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					0 : ROM[0xFA00,4]}U, @{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					1 : ROM[0xFA04,1]}, @{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					0 : ROM[0xFA05,1]&0x1});
	pdc_set_sys_conf(@{
					(ROM[0xF81A,1]&0x03) == 0b00 ? "PDC_SYS_DR_SWAP_DISABLE" :
					(ROM[0xF81A,1]&0x03) == 0b01 ? "PDC_SYS_DR_SWAP_ACTIVE_UFP" :
					(ROM[0xF81A,1]&0x03) == 0b10 ? "PDC_SYS_DR_SWAP_ACTIVE_DFP" :
					(ROM[0xF81A,1]&0x03) == 0b11 ? "PDC_SYS_DR_SWAP_PASSIVE" : ""
					}, @{
					(ROM[0xF81B,1]&0x03) == 0b00 ? "PDC_SYS_PR_SWAP_DISABLE" :
					(ROM[0xF81B,1]&0x03) == 0b01 ? "PDC_SYS_PR_SWAP_ACTIVE_SNK" :
					(ROM[0xF81B,1]&0x03) == 0b10 ? "PDC_SYS_PR_SWAP_ACTIVE_SRC" :
					(ROM[0xF81B,1]&0x03) == 0b11 ? "PDC_SYS_PR_SWAP_PASSIVE" : ""
					}, @{
					(f_F820_27_1 != 0 ? 1 : 0) +
					(f_F81C_1_2 != 0 ? 1 : 0) +
					(f_F81C_3_2 != 0 ? 1 : 0) >= 2
					? "(" : ""
					}@{
					f_F820_27_1 == 0b1 ? "PDC_SYS_UNCNST_PWR" : ""
					}@{
					f_F820_27_1 == 0b1 && f_F81C_1_2 != 0 ? " | " : ""
					}@{
					f_F81C_1_2 == 0b01 ? "PDC_SYS_EXT_PWR_DC" :
					f_F81C_1_2 == 0b11 ? "PDC_SYS_EXT_PWR_AC" : ""
					}@{
					(f_F820_27_1 == 0b1 || f_F81C_1_2 != 0) && f_F81C_3_2 != 0 ? " | " : ""
					}@{
					f_F81C_3_2 == 0b01 ? "PDC_SYS_INTR_PWR_BAT" :
					f_F81C_3_2 == 0b11 ? "PDC_SYS_INTR_PWR_NONBAT" : ""
					}@{
					(f_F820_27_1 != 0 ? 1 : 0) +
					(f_F81C_1_2 != 0 ? 1 : 0) +
					(f_F81C_3_2 != 0 ? 1 : 0) >= 2
					? ")" : ""}@{
					(f_F820_27_1 == 0 && f_F81C_1_2== 0 && f_F81C_3_2 == 0) ? "0" : ""
					}, 0x@{ROM[0xF81D,1]:X2}U);
	pdc_set_dev_stat(0, 0, 0, PDC_TEMP_STAT_NS, 0);
	@{(ROM[0xF904,1] >= 2 && ((ROM[0xF908,2]&0x0030)>>4)==0b11) || (ROM[0xF904,1] >= 3 && ((ROM[0xF908,2]&0x00C0)>>6)==0b11) ||
	(ROM[0xF904,1] >= 4 && ((ROM[0xF908,2]&0x0300)>>8)==0b11) || (ROM[0xF904,1] >= 5 && ((ROM[0xF908,2]&0x0C00)>>10)==0b11) ||
	(ROM[0xF904,1] >= 6 && ((ROM[0xF908,2]&0x3000)>>12)==0b11) || (ROM[0xF904,1] >= 7 && ((ROM[0xF908,2]&0xC000)>>14)==0b11)
	? "pdc_set_pps_stat(0x0, 0xFF);": ""
	}
	pdc_set_pwr_stat(0x00U);
	gRcvMess.uspData = gusRcvMess;
	gSndMess.uspData = gusSndMess;
	pd_core_init(1, 1);
	user_init();
	
	EI();
   /* End user code. Do not edit comment generated here */
}


void user_func_set_snk_intrusive_dis (void)
{
	pdc_set_snk_conf(@{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					0 : ROM[0xFA00,4]}U, @{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					1 : ROM[0xFA04,1]}, 0);
}

void user_func_set_snk_intrusive_en (void)
{
	pdc_set_snk_conf(@{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					0 : ROM[0xFA00,4]}U, @{
					(ROM[0xF818,1]==0b0101000 || ROM[0xF818,1]==0b0111000) ? 
					1 : ROM[0xFA04,1]}, 1);
}
