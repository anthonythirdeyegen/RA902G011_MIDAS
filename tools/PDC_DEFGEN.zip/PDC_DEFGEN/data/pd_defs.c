#include "typedefs.h"

const UCHAR  PD_SPEC_REV = @{ROM[0xF800,1]&0x03}U;          // 1U:PD2, 2U:PD3
const UCHAR  PD_PDM_SPRT_GET_SRCCAP_E   = @{ROM[0xF840,1]&0x01}U;
const UCHAR  PD_PDM_SPRT_GET_BAT_CAP    = @{ROM[0xF841,1]&0x01}U;
const UCHAR  PD_PDM_SPRT_GET_BAT_STATUS = @{ROM[0xF842,1]&0x01}U;
const UCHAR  PD_PDM_SPRT_GET_PPS_STATUS = @{ROM[0xF843,1]&0x01}U;
const UCHAR  PD_PDM_SPRT_GET_MFI        = @{ROM[0xF844,1]&0x01}U;
const UCHAR  PD_PDM_SPRT_GET_SNKCAP_E   = @{ROM[0xF845,1]&0x01}U;

const USHORT PD_VID = 0x@{ROM[0xF802,2]:X4}U;      // Vender ID assigned by the USB-IF
const USHORT PD_PID = 0x@{ROM[0xF804,2]:X4}U;      // Prduct ID assigned by the manufacture
const ULONG  PD_XID = 0x@{ROM[0xF806,4]:X8}UL; // Value provided by the USB-IF assigned to the product
const USHORT PD_BCD_DEVICE = 0x@{ROM[0xF80A,2]:X4}U;     // bcdDevice
const UCHAR  PD_FW_VER     = 0x@{ROM[0xF80C,1]&0x0F:X2}U;        // Firmware version number
const UCHAR  PD_HW_VER     = 0x@{ROM[0xF80D,1]&0x0F:X2}U;        // Hardware version number

const UCHAR PD_USB_COMM_CAPABLE    = 0x@{f_F820_26_1&0x01:X2}U;
const UCHAR PD_IS_USB_HOST         = 0x@{ROM[0xF811,1]&0x01:X2}U;
const UCHAR PD_IS_USB_DEVICE       = 0x@{ROM[0xF812,1]&0x01:X2}U;
const UCHAR PD_USB_SUSPEND_SUPPORT = 0x@{ROM[0xF813,1]&0x01:X2}U;
const UCHAR PD_NO_USB_SUSPEND      = 0x@{ROM[0xF814,1]&0x01:X2}U;
const UCHAR PD_PRODUCT_TYPE_UFP    = 0x@{ROM[0xF815,1]&0x07:X2}U;
const UCHAR PD_PRODUCT_TYPE_DFP    = 0x@{ROM[0xF816,1]&0x07:X2}U;
const UCHAR PD_MODAL_OPE_SUPPORT   = 0x@{ROM[0xF817,1]&0x01:X2}U;

const UCHAR  PD_CONNECTOR_TYPE     = 0x@{ROM[0xF824,1]&0x03:X2}U;
const UCHAR  PD_DEVICE_CAP         = 0x@{ROM[0xF825,1]&0x0F:X2}U;
const UCHAR  PD_HOST_CAP           = 0x@{ROM[0xF826,1]&0x07:X2}U;
const UCHAR  PD_PORT_NUM           = 0x@{ROM[0xF827,1]&0x1F:X2}U;
const USHORT PD_UFP_VDO            = 0x@{ROM[0xF828,2]&0x07FF:X4}U;

const UCHAR  PD_SRC_PDO1_PEAK_CUR  = 0x@{f_F920_20_2:X2}U;
const UCHAR  PD_SNK_PDO1_FR_SWAP_REQ = 0x@{f_FA20_23_2:X2}U;
const USHORT PD_SRC_PDO1_MAX_CUR   = 0x@{f_F920_0_10:X4}U;
const USHORT PD_SNK_PDO1_OPE_CUR     = 0x@{f_FA20_0_10:X4}U;

const ULONG  PD_SRC_PDO2   = 0x@{ROM[0xF904,1]>=2 ? ((ROM[0xF908,2]>>4)&0x3)==0b00 ? (ROM[0xF924,4]) : (ROM[0xF944,4])
												  : 0:X8}U;
const ULONG  PD_SRC_PDO3   = 0x@{ROM[0xF904,1]>=3 ? ((ROM[0xF908,2]>>6)&0x3)==0b00 ? (ROM[0xF928,4]) : (ROM[0xF948,4])
												  : 0:X8}U;
const ULONG  PD_SRC_PDO4   = 0x@{ROM[0xF904,1]>=4 ? ((ROM[0xF908,2]>>8)&0x3)==0b00 ? (ROM[0xF92C,4]) : (ROM[0xF94C,4])
												  : 0:X8}U;
const ULONG  PD_SRC_PDO5   = 0x@{ROM[0xF904,1]>=5 ? ((ROM[0xF908,2]>>10)&0x3)==0b00 ? (ROM[0xF930,4]) : (ROM[0xF950,4])
												  : 0:X8}U;
const ULONG  PD_SRC_PDO6   = 0x@{ROM[0xF904,1]>=6 ? ((ROM[0xF908,2]>>12)&0x3)==0b00 ? (ROM[0xF934,4]) : (ROM[0xF954,4])
												  : 0:X8}U;
const ULONG  PD_SRC_PDO7   = 0x@{ROM[0xF904,1]>=7 ? ((ROM[0xF908,2]>>14)&0x3)==0b00 ? (ROM[0xF938,4]) : (ROM[0xF958,4])
												  : 0:X8}U;

const ULONG  PD_SNK_PDO2   = 0x@{ROM[0xFA04,1]>=2 ?
								 (ROM[0xFA08,2]>>4&0x3)==0b00 ? (ROM[0xFA24,4]) :
								 (ROM[0xFA08,2]>>4&0x3)==0b10 ? (ROM[0xFA44,4]) :
								 (ROM[0xFA08,2]>>4&0x3)==0b01 ? (ROM[0xFA64,4]) : (ROM[0xFA84,4])
								 : 0:X8}U;
const ULONG  PD_SNK_PDO3   = 0x@{ROM[0xFA04,1]>=3 ?
								 (ROM[0xFA08,2]>>6&0x3)==0b00 ? (ROM[0xFA28,4]) :
								 (ROM[0xFA08,2]>>6&0x3)==0b10 ? (ROM[0xFA48,4]) :
								 (ROM[0xFA08,2]>>6&0x3)==0b01 ? (ROM[0xFA68,4]) : (ROM[0xFA88,4])
								 : 0:X8}U;
const ULONG  PD_SNK_PDO4   = 0x@{ROM[0xFA04,1]>=4 ?
								 (ROM[0xFA08,2]>>8&0x3)==0b00 ? (ROM[0xFA2C,4]) :
								 (ROM[0xFA08,2]>>8&0x3)==0b10 ? (ROM[0xFA4C,4]) :
								 (ROM[0xFA08,2]>>8&0x3)==0b01 ? (ROM[0xFA6C,4]) : (ROM[0xFA8C,4])
								 : 0:X8}U;
const ULONG  PD_SNK_PDO5   = 0x@{ROM[0xFA04,1]>=5 ?
								 (ROM[0xFA08,2]>>10&0x3)==0b00 ? (ROM[0xFA30,4]) :
								 (ROM[0xFA08,2]>>10&0x3)==0b10 ? (ROM[0xFA50,4]) :
								 (ROM[0xFA08,2]>>10&0x3)==0b01 ? (ROM[0xFA70,4]) : (ROM[0xFA90,4])
								 : 0:X8}U;
const ULONG  PD_SNK_PDO6   = 0x@{ROM[0xFA04,1]>=6 ?
								 (ROM[0xFA08,2]>>12&0x3)==0b00 ? (ROM[0xFA34,4]) :
								 (ROM[0xFA08,2]>>12&0x3)==0b10 ? (ROM[0xFA54,4]) :
								 (ROM[0xFA08,2]>>12&0x3)==0b01 ? (ROM[0xFA74,4]) : (ROM[0xFA94,4])
								 : 0:X8}U;
const ULONG  PD_SNK_PDO7   = 0x@{ROM[0xFA04,1]>=7 ?
								 (ROM[0xFA08,2]>>14&0x3)==0b00 ? (ROM[0xFA38,4]) :
								 (ROM[0xFA08,2]>>14&0x3)==0b10 ? (ROM[0xFA58,4]) :
								 (ROM[0xFA08,2]>>14&0x3)==0b01 ? (ROM[0xFA78,4]) : (ROM[0xFA98,4])
								 : 0:X8}U;

const UCHAR  PD_SCEDB_VOLT_REG    = 0x@{ROM[0xF850,1]:X2}U;
const UCHAR  PD_SCEDB_HOLDUP_TIME = 0x@{ROM[0xF851,1]:X2}U;
const UCHAR  PD_SCEDB_COMPLIANCE  = 0x@{ROM[0xF852,1]:X2}U;
const UCHAR  PD_SCEDB_TOUCH_CUR   = 0x@{ROM[0xF853,1]:X2}U;
const USHORT PD_SCEDB_PEAK_CUR1   = 0x@{ROM[0xF854,2]:X4}U;
const USHORT PD_SCEDB_PEAK_CUR2   = 0x@{ROM[0xF856,2]:X4}U;
const USHORT PD_SCEDB_PEAK_CUR3   = 0x@{ROM[0xF858,2]:X4}U;
const UCHAR  PD_SCEDB_TOUCH_TEMP  = 0x@{ROM[0xF85A,1]:X2}U;
const UCHAR  PD_SCEDB_BATTERIES   = 0x@{ROM[0xF85C,1]:X2}U;
const UCHAR  PD_SCEDB_SRC_PDP     = @{ROM[0xF85D,1]:D}U;

const UCHAR  PD_SKEDB_VERSION     = 0x01U;
const UCHAR  PD_SKEDB_LOAD_STEP   = 0x@{ROM[0xF881,1]:X2}U;
const USHORT PD_SKEDB_LOAD_CHARA  = 0x@{ROM[0xF882,2]:X4}U;
const UCHAR  PD_SKEDB_COMPLIANCE  = 0x@{ROM[0xF884,1]:X2}U;
const UCHAR  PD_SKEDB_TOUCH_TEMP  = 0x@{ROM[0xF885,1]:X2}U;
const UCHAR  PD_SKEDB_BAT_INFO    = 0x@{ROM[0xF886,1]:X2}U;
const UCHAR  PD_SKEDB_SNK_MODES   = 0x@{ROM[0xF887,1]:X2}U;
const UCHAR  PD_SKEDB_SNK_MIN_PDP = 0x@{ROM[0xF888,1]:X2}U;
const UCHAR  PD_SKEDB_SNK_OPE_PDP = 0x@{ROM[0xF889,1]:X2}U;
const UCHAR  PD_SKEDB_SNK_MAX_PDP = 0x@{ROM[0xF88A,1]:X2}U;


const UCHAR  PD_NUM_OF_MFI_STR = @{ROM[0xF860,1]:D}U;
const UCHAR  PD_MFI_STR01  = '@{ROM[0xF861,1]:C}';
const UCHAR  PD_MFI_STR02  = '@{ROM[0xF862,1]:C}';
const UCHAR  PD_MFI_STR03  = '@{ROM[0xF863,1]:C}';
const UCHAR  PD_MFI_STR04  = '@{ROM[0xF864,1]:C}';
const UCHAR  PD_MFI_STR05  = '@{ROM[0xF865,1]:C}';
const UCHAR  PD_MFI_STR06  = '@{ROM[0xF866,1]:C}';
const UCHAR  PD_MFI_STR07  = '@{ROM[0xF867,1]:C}';
const UCHAR  PD_MFI_STR08  = '@{ROM[0xF868,1]:C}';
const UCHAR  PD_MFI_STR09  = '@{ROM[0xF869,1]:C}';
const UCHAR  PD_MFI_STR10  = '@{ROM[0xF86A,1]:C}';
const UCHAR  PD_MFI_STR11  = '@{ROM[0xF86B,1]:C}';
const UCHAR  PD_MFI_STR12  = '@{ROM[0xF86C,1]:C}';
const UCHAR  PD_MFI_STR13  = '@{ROM[0xF86D,1]:C}';
const UCHAR  PD_MFI_STR14  = '@{ROM[0xF86E,1]:C}';
const UCHAR  PD_MFI_STR15  = '@{ROM[0xF86F,1]:C}';
const UCHAR  PD_MFI_STR16  = '@{ROM[0xF870,1]:C}';
const UCHAR  PD_MFI_STR17  = '@{ROM[0xF871,1]:C}';
const UCHAR  PD_MFI_STR18  = '@{ROM[0xF872,1]:C}';
const UCHAR  PD_MFI_STR19  = '@{ROM[0xF873,1]:C}';
const UCHAR  PD_MFI_STR20  = '@{ROM[0xF874,1]:C}';
const UCHAR  PD_MFI_STR21  = '@{ROM[0xF875,1]:C}';
const UCHAR  PD_MFI_STR22  = '@{ROM[0xF876,1]:C}';

const USHORT PD_SND_MESS_SIZE = @{ROM[0xF8C0,2]*2:D}U;
const USHORT PD_RCV_MESS_SIZE = @{ROM[0xF8C2,2]*2:D}U;
